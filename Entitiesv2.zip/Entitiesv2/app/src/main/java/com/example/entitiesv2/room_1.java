package com.example.entitiesv2;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class room_1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.jardin);



        final Button entree = findViewById(R.id.entree);
        entree.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                startActivity(new Intent(room_1.this, room_2.class));
                // aller à la page entrée
            }
        });

    }}
