package com.example.entitiesv2;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class room_6 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.buanderie);



        final Button cuisine = findViewById(R.id.cuisine);
        cuisine.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                startActivity(new Intent(room_6.this, room_5.class));
                // démarre l'activité cuisine
            }
        });


        final Button s_a_m = findViewById(R.id.s_a_m);
        s_a_m.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                startActivity(new Intent(room_6.this, room_4.class));
                // démarre l'activité salle à manger
            }
        });


        final Button garage = findViewById(R.id.garage);
        garage.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                startActivity(new Intent(room_6.this, room_12.class));
                // démarre l'activité garage
            }
        });
    }}
