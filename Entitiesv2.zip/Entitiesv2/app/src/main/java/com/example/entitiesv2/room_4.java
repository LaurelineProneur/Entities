package com.example.entitiesv2;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class room_4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.s_a_m);



        final Button entree= findViewById(R.id.entree);
        entree.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                startActivity(new Intent(room_4.this, room_2.class));
                // démarre l'activité entree
            }
        });
        final Button cuisine = findViewById(R.id.cuisine);
        cuisine.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                startActivity(new Intent(room_4.this, room_5.class));
                // démarre l'activité cuisine
            }
        });
    }}
