package com.example.entitiesv2;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class room_9 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ch_enfant);



        final Button couloir = findViewById(R.id.couloir);
        couloir.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                startActivity(new Intent(room_9.this, room_7.class));
                // démarre l'activité couloir
            }
        });
    }}
